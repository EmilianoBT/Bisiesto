<?php include("header.php") ?>
<script src="bisiesto.js"></script>
<div class="container">
    <h1>Calculadora de años bisiestos</h1>
    <h2>Ingrese los años que desee calcular</h2>
<input type= "number" id="año1"></input>
<input type= "number" id="año2"></input>
<button onclick="calcular()">Calcular</button>
<p id="ejecutar">Esperando valores...</p>
    
</div>
<?php include("footer.php") ?>