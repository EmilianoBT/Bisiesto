function ejecutar(){
    var año1 = document.getElementById("año1").value;
    var año2 = document.getElementById("año2").value;
    var dic_elementos = document.getElementById("elementos");

    for(let i = año1; i < año2; i++){
        if(i %4 == 0){
            dic_elementos.innerHTML += '<p class="bisiesto">' + i + 'Es un año bisiesto</p>';

        }else{
            dic_elementos.innerHTML += '<p class="no_bisiesto">' + i + 'No es un año bisiesto</p>';

        }
    }
    function contarAniosBisiestos(desde, hasta) {
        let contador = 0;
        
        for (let año = desde; año <= hasta; año++) {
            if (esBisiesto(año)) {
                contador++;
            }
        }
    }
}